import { Document, InsertDocument } from "@shared/schema";
import fs from "fs";
import path from "path";

export interface IStorage {
  getAllDocuments(): Promise<Document[]>;
  getDocument(path: string): Promise<Document | undefined>;
  createDocument(doc: InsertDocument): Promise<Document>;
  searchDocuments(query: string): Promise<Document[]>;
}

export class MemStorage implements IStorage {
  private docs: Map<string, Document>;
  private currentId: number;

  constructor() {
    this.docs = new Map();
    this.currentId = 1;
    this.initializeFromFolder();
  }

  private readDirRecursively(dirPath: string, relativePath: string = ''): void {
    const files = fs.readdirSync(dirPath);

    files.forEach(file => {
      const fullPath = path.join(dirPath, file);
      const stats = fs.statSync(fullPath);
      const fileRelativePath = path.join(relativePath, file);

      if (stats.isDirectory()) {
        this.readDirRecursively(fullPath, fileRelativePath);
      } else if (file.endsWith('.md')) {
        const content = fs.readFileSync(fullPath, 'utf-8');
        const title = path.basename(file, '.md');

        const doc: Document = {
          id: this.currentId++,
          path: fileRelativePath,
          title: title.replace(/-/g, ' '),
          content
        };

        this.docs.set(doc.path, doc);
      }
    });
  }

  private initializeFromFolder() {
    try {
      const folderPath = path.join(process.cwd(), '2025MUN');
      this.readDirRecursively(folderPath);
    } catch (error) {
      console.error('Error reading 2025MUN folder:', error);
    }
  }

  async getAllDocuments(): Promise<Document[]> {
    return Array.from(this.docs.values());
  }

  async getDocument(path: string): Promise<Document | undefined> {
    return this.docs.get(path);
  }

  async createDocument(insertDoc: InsertDocument): Promise<Document> {
    const id = this.currentId++;
    const doc: Document = { ...insertDoc, id };
    this.docs.set(doc.path, doc);
    return doc;
  }

  async searchDocuments(query: string): Promise<Document[]> {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.docs.values()).filter(
      doc => 
        doc.title.toLowerCase().includes(lowercaseQuery) ||
        doc.content.toLowerCase().includes(lowercaseQuery)
    );
  }
}

export const storage = new MemStorage();