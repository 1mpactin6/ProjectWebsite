import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/docs", async (_req, res) => {
    const docs = await storage.getAllDocuments();
    res.json(docs);
  });

  app.get("/api/docs/:path", async (req, res) => {
    const doc = await storage.getDocument(req.params.path);
    if (!doc) {
      res.status(404).json({ message: "Document not found" });
      return;
    }
    res.json(doc);
  });

  app.get("/api/search", async (req, res) => {
    const query = req.query.q as string;
    if (!query) {
      res.json([]);
      return;
    }
    const results = await storage.searchDocuments(query);
    res.json(results);
  });

  const httpServer = createServer(app);
  return httpServer;
}
