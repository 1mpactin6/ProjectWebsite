
**Speech Summary:** _The following information are speeches spoken by others in a MUN conference, analyze the words and gather information about the STANCE, SUGGESTIONS, and OVERVIEW. Then write three paragraphs with bullet point that summarizes the key points of the speech:_

> **Resolution Amendment:** _This is about MUN. The following or attached file is a resolution for the topics given on the top part, gather information about the resolution, and write a quick summary about the resolution, then generate AMENDMENT ideas about the resolution. Generate three lists for Friendly, Unfriendly Strike/Modify, and Unfriendly Add/Modify ideas, generate bullet points for the list providing at least 5 ideas for each list, and give location in resolution, main idea/thesis, reasons, and evidence _

> **Amendment Ideas:** _Generate additional information for the following information about an amendment for MUN, the topics are United Nations Development Programme (UNDP) Topic 1: On measures to build sustainable digital infrastructure to enable AI-driven growth.
> 	Topic 2: On measures to encourage digital literacy among the youth to bridge the digital divide. Generate the Key Points of this amendment add evidences and supporting reasons, and generate a quick stance of Mexico looking at these suggestions. The information are bellow:_

> **Resolution Analysis for Amendment Ideas regardingly:** _Analyze the given information, following the steps below: 1. Read the overall and gather basic information about the Resolution for MUN 2. Gather information about the clauses to have an overview of the situation and topic 3. Now regarding to the topic and committee 4. Now point out find potential errors for amendments 5. Give the following information in bullet-point note style form: The name of the amendment (Friendly, Unfriendly strike, add, or modify. The basic summary of the amending point. The clause and sub clause that the amendment amends. Point of key points and reason of the amendment._

Input PromptGenius and PromptUltimate to get optimized prompts 9compare it0

> **Speech to POIs:** _This is the recording of the speeches spoken for MUN for the topic:
> On measures to build sustainable digital infrastructure to enable AI-driven growth.
> On measures to encourage digital literacy among the youth to bridge the digital divide.
> Create questions regarding to the style of the speech and make questions for other types of speeches generally._