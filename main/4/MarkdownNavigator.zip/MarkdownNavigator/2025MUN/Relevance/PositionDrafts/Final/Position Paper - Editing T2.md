
*Country: Mexico*
*Committee: United Nations Development Programme (UNDP)*
*Topic 2: Measures to Encourage Digital Literacy Among Youth to Bridge the Digital Divide*

**Part A - Background:**

The digital divide among youth is a huge barrier 