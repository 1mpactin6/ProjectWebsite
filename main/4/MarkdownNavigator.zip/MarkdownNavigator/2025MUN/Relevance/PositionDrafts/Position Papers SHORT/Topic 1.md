
*Country: Mexico*
*Committee: United Nations Development Program (UNDP)*
*Topic 1: Measures to Build Sustainable Digital Infrastructure to Enable AI-Driven Growth*

**Honorable Chair, Esteemed Delegates, and Distinguished Guests:**

1. 