import { Link } from "wouter";

export function Footer() {
  return (
    <footer className="border-t border-border/40 bg-slate-950">
      <div className="container flex flex-col items-center justify-between gap-4 py-10 md:h-24 md:flex-row md:py-0">
        <div className="flex flex-col items-center gap-4 px-8 md:flex-row md:gap-2 md:px-0">
          <p className="text-center text-sm leading-loose text-slate-300 md:text-left">
            Built for 2025 Model United Nations Conference
          </p>
        </div>
        <nav className="flex items-center space-x-6 text-sm font-medium">
          <Link href="/docs/about" className="text-slate-300 hover:text-slate-100">
            About
          </Link>
          <Link href="/docs/contact" className="text-slate-300 hover:text-slate-100">
            Contact
          </Link>
        </nav>
      </div>
    </footer>
  );
}
