import { useEffect, useState } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";

interface TOCItem {
  id: string;
  text: string;
  level: number;
}

export function TableOfContents() {
  const [items, setItems] = useState<TOCItem[]>([]);
  const [activeId, setActiveId] = useState<string>("");

  useEffect(() => {
    const headings = Array.from(document.querySelectorAll("h1, h2, h3, h4, h5, h6"));
    const tocItems = headings.map((heading) => ({
      id: heading.id,
      text: heading.textContent || "",
      level: parseInt(heading.tagName[1]),
    }));
    setItems(tocItems);

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveId(entry.target.id);
          }
        });
      },
      { rootMargin: "0px 0px -80% 0px" }
    );

    headings.forEach((heading) => observer.observe(heading));
    return () => observer.disconnect();
  }, []);

  return (
    <ScrollArea className="h-[calc(100vh-65px)]">
      <div className="p-4 space-y-2">
        <h2 className="font-semibold mb-4">Table of Contents</h2>
        {items.map((item) => (
          <a
            key={item.id}
            href={`#${item.id}`}
            className={`block text-sm py-1 pl-${(item.level - 1) * 4} hover:text-primary transition-colors ${
              activeId === item.id ? "text-primary font-medium" : "text-muted-foreground"
            }`}
          >
            {item.text}
          </a>
        ))}
      </div>
    </ScrollArea>
  );
}
