import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Document } from "@shared/schema";
import { Input } from "@/components/ui/input";
import { Link } from "wouter";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Search as SearchIcon } from "lucide-react";

export function Search() {
  const [query, setQuery] = useState("");
  const { data: results } = useQuery<Document[]>({ 
    queryKey: ["/api/search", query],
    enabled: query.length > 0
  });

  return (
    <div className="relative">
      <div className="relative">
        <SearchIcon className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search documentation..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="pl-10"
        />
      </div>
      
      {query.length > 0 && results && results.length > 0 && (
        <ScrollArea className="absolute top-full mt-2 w-full bg-background border rounded-lg shadow-lg z-50 max-h-[300px]">
          <div className="p-2">
            {results.map((doc) => (
              <Link
                key={doc.id}
                href={`/docs/${doc.path}`}
                className="block p-2 hover:bg-accent rounded-md"
                onClick={() => setQuery("")}
              >
                {doc.title}
              </Link>
            ))}
          </div>
        </ScrollArea>
      )}
    </div>
  );
}
