import { ScrollArea } from "@/components/ui/scroll-area";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Document } from "@shared/schema";
import { cn } from "@/lib/utils";
import { ChevronDown, ChevronRight, File, Folder } from "lucide-react";
import { useState } from "react";

interface FolderStructure {
  [key: string]: {
    type: 'folder' | 'file';
    name: string;
    path?: string;
    children?: FolderStructure;
  };
}

function buildFolderStructure(docs: Document[]): FolderStructure {
  const structure: FolderStructure = {};

  docs.forEach(doc => {
    const parts = doc.path.split('/');
    let current = structure;

    parts.forEach((part, index) => {
      if (index === parts.length - 1) {
        // File
        current[part] = {
          type: 'file',
          name: doc.title,
          path: doc.path
        };
      } else {
        // Folder
        if (!current[part]) {
          current[part] = {
            type: 'folder',
            name: part,
            children: {}
          };
        }
        current = current[part].children!;
      }
    });
  });

  return structure;
}

interface NavItemProps {
  name: string;
  item: FolderStructure[string];
  level?: number;
}

function NavItem({ name, item, level = 0 }: NavItemProps) {
  const [isOpen, setIsOpen] = useState(true);
  const [location] = useLocation();

  if (item.type === 'file') {
    return (
      <Link
        href={`/docs/${item.path}`}
        className={cn(
          "flex items-center gap-2 py-1 px-2 rounded-lg hover:bg-slate-900/50 transition-colors text-slate-300",
          location === `/docs/${item.path}` && "bg-slate-900 text-slate-100",
          level > 0 && "ml-6"
        )}
      >
        <File className="h-4 w-4" />
        <span>{item.name}</span>
      </Link>
    );
  }

  return (
    <div>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
          "flex items-center gap-2 py-1 px-2 rounded-lg hover:bg-slate-900/50 transition-colors text-slate-300 w-full text-left",
          level > 0 && "ml-6"
        )}
      >
        {isOpen ? (
          <ChevronDown className="h-4 w-4" />
        ) : (
          <ChevronRight className="h-4 w-4" />
        )}
        <Folder className="h-4 w-4" />
        <span>{item.name}</span>
      </button>
      {isOpen && item.children && (
        <div className="mt-1">
          {Object.entries(item.children).map(([childName, child]) => (
            <NavItem
              key={childName}
              name={childName}
              item={child}
              level={level + 1}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export function Sidebar() {
  const { data: docs } = useQuery<Document[]>({ 
    queryKey: ["/api/docs"],
  });

  const structure = docs ? buildFolderStructure(docs) : {};

  return (
    <div className="w-64 border-r border-border/40 bg-slate-950 h-screen">
      <div className="p-4 border-b border-border/40">
        <h1 className="text-xl font-bold text-slate-100">2025 MUN Docs</h1>
      </div>
      <ScrollArea className="h-[calc(100vh-65px)]">
        <div className="p-4 space-y-2">
          {Object.entries(structure).map(([name, item]) => (
            <NavItem key={name} name={name} item={item} />
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}