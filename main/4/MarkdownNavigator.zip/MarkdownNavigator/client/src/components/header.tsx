import { Search } from "./search";
import { Link } from "wouter";

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-slate-950/80 backdrop-blur supports-[backdrop-filter]:bg-slate-950/80">
      <div className="container flex h-14 max-w-screen-2xl items-center">
        <div className="mr-4 flex">
          <Link href="/" className="mr-6 flex items-center space-x-2">
            <span className="hidden font-bold text-slate-100 sm:inline-block">
              2025 MUN Documentation
            </span>
          </Link>
          <nav className="flex items-center space-x-6 text-sm font-medium">
            <Link href="/docs/getting-started" className="text-slate-300 hover:text-slate-100">
              Getting Started
            </Link>
            <Link href="/docs/guides" className="text-slate-300 hover:text-slate-100">
              Guides
            </Link>
            <Link href="/docs/reference" className="text-slate-300 hover:text-slate-100">
              Reference
            </Link>
          </nav>
        </div>
        <div className="flex flex-1 items-center justify-end space-x-2">
          <div className="w-full flex-1 md:w-auto md:flex-none">
            <Search />
          </div>
        </div>
      </div>
    </header>
  );
}
