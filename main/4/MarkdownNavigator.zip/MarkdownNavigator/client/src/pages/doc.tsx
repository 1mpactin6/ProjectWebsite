import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Document } from "@shared/schema";
import { Markdown } from "@/components/ui/markdown";
import { TableOfContents } from "@/components/table-of-contents";

export default function Doc() {
  const { path } = useParams();
  const { data: doc, isLoading } = useQuery<Document>({
    queryKey: [`/api/docs/${path}`],
  });

  if (isLoading) {
    return (
      <div className="p-8 bg-slate-950 text-slate-300">
        <div className="h-8 w-48 bg-slate-900 rounded animate-pulse mb-4" />
        <div className="space-y-3">
          <div className="h-4 w-full bg-slate-900 rounded animate-pulse" />
          <div className="h-4 w-5/6 bg-slate-900 rounded animate-pulse" />
          <div className="h-4 w-4/6 bg-slate-900 rounded animate-pulse" />
        </div>
      </div>
    );
  }

  if (!doc) {
    return (
      <div className="p-8 bg-slate-950 text-slate-300">
        <h1 className="text-2xl font-bold mb-4">Document not found</h1>
        <p className="text-slate-400">
          The document you're looking for doesn't exist.
        </p>
      </div>
    );
  }

  return (
    <div className="flex-1 flex bg-slate-950">
      <div className="flex-1 p-8">
        <h1 className="text-3xl font-bold mb-6 text-slate-100">{doc.title}</h1>
        <Markdown content={doc.content} className="text-slate-300" />
      </div>
      <div className="w-64 border-l border-border/40 hidden lg:block">
        <TableOfContents />
      </div>
    </div>
  );
}