import { Search } from "@/components/search";

export default function Home() {
  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-6">Documentation</h1>
      <p className="text-lg text-muted-foreground mb-8">
        Welcome to the documentation. Use the search below or browse through the sidebar.
      </p>
      <Search />
    </div>
  );
}
