---
name: Feast
site: https://feast.dev/
status: trial
topic: 
 - machine learning
 - systems
history:
  - 2021-03-14: trial
  - 2021-03-07: assess
---

# Feast
[[Feast]] is a [[Feature Store]] for [[Machine Learning]].


## Reasoning for
1. Open source

## Reasoning against
1. ...

## Alternatives considered
1. [[Tecton]]

## Resources
Link to relevant blog posts here.