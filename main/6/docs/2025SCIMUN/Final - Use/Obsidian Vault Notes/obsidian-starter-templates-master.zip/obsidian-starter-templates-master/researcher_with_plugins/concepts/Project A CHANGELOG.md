[[Project A]]
# Project A CHANGELOG
Many open source projects have a changelog for tracking project history – this typically exists as a local `CHANGELOG.md` file.

You can track history for [[Project A]] is this changelog here.

## Phase 2: If you're using phases
- [ ] More new ideas go here

## Phase 1
- [ ] Feature Three: Still working on this
- [x] Feature Two: Got this one done
	- [x] Sub-Feature A: Explanation can goe here
- [x] Feature One: Free-form text goes here
- [x] Work out whether we should use [[Golang]] or [[Rust]]