## Today I learnt
Backlinks to surprising ideas or new takes on existing ideas.

> Look at backlinks to find the content.
