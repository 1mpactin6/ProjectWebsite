#moc 

# Model Serving

Here you can summarise what [[Model Serving]] actually is and go on to summarise some of the tools that have been considered.

We may give a quick summary of [[Seldon Core]] and what makes it different to [[Bento ML]].

There's no need to list all of the [[Model Serving]] tools considered as we can rely on backlinks to [[Model Serving]] to do that for us.