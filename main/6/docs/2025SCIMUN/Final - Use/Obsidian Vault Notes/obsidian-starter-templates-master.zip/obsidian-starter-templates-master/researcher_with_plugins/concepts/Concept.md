# An example concept note

This page might explore an import concept using ideas from multiple references: for example, [[@butcher2016go]] may recommend Golang for everything, while [[@mcnamara2021rust]] may recommend Rust.

You can highlight that this concept is relevant for specific projects such as [[Project A]].