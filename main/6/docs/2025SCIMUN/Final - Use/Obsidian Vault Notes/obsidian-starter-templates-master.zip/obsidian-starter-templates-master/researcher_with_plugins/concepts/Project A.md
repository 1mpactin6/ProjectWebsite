# Project A

This page is a Map of Content (see [In what ways can we form useful relationships between notes \[LONG READ\]](https://forum.obsidian.md/t/in-what-ways-can-we-form-useful-relationships-between-notes-long-read/702)) for [[Project A]].

You can use this Map of Content for different purposes such as summarising who is involved with this project: such as [[Supervisor]] and [[Collaborator A]].

## Concepts:

Maybe you have a sentence explaining why [[Concept]] is important for [[Project A]].

## References:

You could list brief opinions regarding the key references of [[Project A]] such as [[@butcher2016go]] and [[@mcnamara2021rust]].

## Trackers:

[[Project A]] has two trackers:
- [[Project A ROADMAP]] for planning the future
- [[Project A CHANGELOG]] for reflecting on the past