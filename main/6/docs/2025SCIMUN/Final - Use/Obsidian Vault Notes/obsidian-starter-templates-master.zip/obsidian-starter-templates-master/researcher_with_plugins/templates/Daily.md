📆 [[{{tp_yesterday}}]] – [[{{tp_tomorrow}}]]

You can now have templated daily notes using the [Templater](https://github.com/SilentVoid13/Templater) plugin. This example will put links to yesterday's and tomorrow's notes at the top of the daily note.