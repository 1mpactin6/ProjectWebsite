---
name: Weights & Biases
site: https://wandb.ai/site
status: assess
topic: 
 - machine learning
history:
  - 2021-03-14: assess
---

# Weights & Biases 
MLflow is an [[Experiment Tracking]] framework for [[Machine Learning]]. 

## Reasoning for
1. ...

## Reasoning against

1. ...

## Alternatives considered
1. [[MLflow]]

## Resources
Link to relevant blog posts here.