# A new useful concept
- [[Saini (2017) – Inferior]] described it like this, but [[Csikszentmihalyi (2008) – Flow]] described it like that.

## More detail
This link appears many times,[^repeated] so uses a footnote. A reference[^repeated] had an even different idea to [[Csikszentmihalyi (2008) – Flow]]. 

This concept only appeared once, so just paste link. 
https://en.wikipedia.org/wiki/Mental_state

[[Collaborator A]] has a good idea about this, but [[Supervisor]] thinks that this is wrong. I need to check.[^repeated]

## References
[^repeated]: Flow (psychology): https://en.wikipedia.org/wiki/Flow_(psychology)