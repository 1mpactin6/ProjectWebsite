# Wins
 Keep a record of any positive feedback by linking to [[Wins]].
 
 > Look at backlinks to find the content.