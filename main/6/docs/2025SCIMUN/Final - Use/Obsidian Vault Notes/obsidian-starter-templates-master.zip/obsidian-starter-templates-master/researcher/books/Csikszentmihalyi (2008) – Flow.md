# Csikszentmihalyi – Flow
Csikszentmihalyi, M. (2008) Flow: The Psychology of Optimal Experience.

---

- One of the chapters focused on [[A concept]]
- Not sure what the point of this is. #question