#moc 

# Feature Store

Here you can summarise what [[Feature Store]] actually are and go on to summarise some of the tools that have been considered.

We may give a quick summary of [[Feast]] and what makes it different to [[Tecton]].

There's no need to list off the [[Feature Store]] tools considered as we can rely on backlinks to [[Feature Store]] to do that for us.