---
title: Rust in Action
authors: Tim McNamara
year: 2021
---

