# Rust

Here I'm working on example concept from [[@mcnamara2021rust]]:

```rust
fn main() {
    println!("Hello from rust");
}
```