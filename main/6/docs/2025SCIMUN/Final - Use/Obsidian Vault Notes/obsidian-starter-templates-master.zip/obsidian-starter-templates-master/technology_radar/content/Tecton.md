---
name: Tecton
site: https://www.tecton.ai/
status: assess
topic: 
 - machine learning
 - systems
history:
  - 2021-03-14: assess
---

# Tecton
[[Tecton]] is a [[Feature Store]] for [[Machine Learning]].


## Reasoning for
1. ...

## Reasoning against
1. ...

## Alternatives considered
1. [[Feast]]

## Resources
Link to relevant blog posts here.