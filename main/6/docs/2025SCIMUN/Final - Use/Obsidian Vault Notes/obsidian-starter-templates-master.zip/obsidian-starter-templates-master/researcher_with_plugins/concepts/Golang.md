# Golang

Here I'm working on an example concept from [[@butcher2016go]]:

```go
package main

import "fmt"

func main() {
    fmt.Println("Hello from go")
}
```