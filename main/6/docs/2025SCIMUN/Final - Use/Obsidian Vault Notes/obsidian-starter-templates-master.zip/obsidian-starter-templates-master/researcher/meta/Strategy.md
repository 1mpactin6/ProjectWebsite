# Strategy
Constantly question your approaches here and keep a record of insights and meta concepts.

> Don't over-obsess or over-formalize this stuff. Remember: "Better note-taking" misses the point; what matters is "better thinking".
> — Andy Matuschak <https://notes.andymatuschak.org/Taxonomy_of_note_types