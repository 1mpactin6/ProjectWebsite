#moc 

# Graph Database

Here you can summarise what [[Graph Database]] actually are and go on to summarise some of the tools that have been considered.

We may give a quick summary of [[Dgraph]] and what makes it different to [[Neo4j]].

There's no need to list all the [[Graph Database]] considered as we can rely on backlinks to [[Model Serving]] to do that for us.