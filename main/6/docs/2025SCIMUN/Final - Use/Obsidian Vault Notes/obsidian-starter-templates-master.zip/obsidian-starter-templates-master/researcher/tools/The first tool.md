# The first tool
Write notes here about a tool or technique. 

If #the-tool is mentioned in passing in other notes, you could use tag (for example #the-tool ).

If the association is stronger, you could use a link to [[The first tool]].

![[panda.jpg]]