# Contributing to Obsidian Starter Templates

👍🎉 First off, thanks for taking the time to contribute! 🎉👍

## How can I contribute?

### Example templates

If you've discovered a useful way of working with Obsidian, consider creating a starter template and sharing with the community. We warmly welcome any pull requests.