---
name: Dgraph
site: https://dgraph.io/
status: adopt
topic:
  - systems
history:
  - 2021-03-14: adopt
  - 2021-03-07: assess
---

# Dgraph
[[Dgraph]] is a [[Graph Database]].

## Reasoning for
1. Open source.
2. ...
## Reasoning against
1. ...

## Resources
Link to relevant blog posts here.