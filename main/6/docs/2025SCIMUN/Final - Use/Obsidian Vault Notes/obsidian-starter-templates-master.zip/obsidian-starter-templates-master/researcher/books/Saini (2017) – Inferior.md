# Saini – Inferior

Saini, A. (2017). Inferior.

---

- [[A concept]] came from this