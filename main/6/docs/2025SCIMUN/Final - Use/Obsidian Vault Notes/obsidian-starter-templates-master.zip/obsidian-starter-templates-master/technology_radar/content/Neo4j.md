---
name: Neo4j
site: https://neo4j.com/
status: assess
topic:
  - systems
history:
  - 2021-03-14: assess
---

# Tool
[[Neo4j]] is a [[Graph Database]]. 

## Reasoning for
1. ...

## Reasoning against
1. ...

## Resources
Link to relevant blog posts here.