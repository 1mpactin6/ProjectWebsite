# Project B
A project description will need to go here.

## People
- [[Supervisor]]
- [[Collaborator B]]