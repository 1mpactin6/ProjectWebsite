---
name: Bento ML
site: https://github.com/bentoml/BentoML
status: assess
topic: 
 - machine learning
 - systems
history:
  - 2021-03-14: assess
---

# Bento ML

[[Bento ML]] is a framework for deploying [[Machine Learning]] models – it enables [[Model Serving]].

## Reasoning for
1. Open source
2. ...

## Reasoning against

## Alternatives considered
1. [[Seldon Core]]

## Resources
Link to relevant blog posts here.