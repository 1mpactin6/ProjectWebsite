---
title: Go in practice
authors: Matt Butcher, Matt Farina
year: 2016
---

# Go in practice

Summary of the book chapters could go here. Write notes on particular concepts elsewhere and refer back to this page using [@butcher2016go].

You can add citations using "Citations: Insert Markdown citation" in the Obsidian command pallete.