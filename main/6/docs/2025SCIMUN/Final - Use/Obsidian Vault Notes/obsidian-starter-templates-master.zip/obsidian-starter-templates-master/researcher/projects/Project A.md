# Project A
Project A started out as a single notes (like the otheres) but grew into its own folder of concepts.

## People
- [[Supervisor]]
- [[Collaborator A]]
- [[Collaborator B]] might be interested.

## Ideas
We're going to expand on [[Main concept]] and show how it relates to [[A concept]].