import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { type BlogPost } from "@shared/schema";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { format } from "date-fns";

export default function BlogPostPage() {
  const [, params] = useRoute("/blog/:slug");
  const slug = params?.slug;

  const { data: post, isLoading } = useQuery<BlogPost>({
    queryKey: [`/api/blog-posts/${slug}`],
    enabled: !!slug,
  });

  if (isLoading) {
    return (
      <div className="container max-w-4xl mx-auto px-4 py-24">
        <Card className="animate-pulse">
          <CardContent className="p-8">
            <div className="h-8 bg-muted rounded w-3/4 mb-4" />
            <div className="h-4 bg-muted rounded w-1/2 mb-8" />
            <div className="space-y-4">
              {Array(5).fill(0).map((_, i) => (
                <div key={i} className="h-4 bg-muted rounded w-full" />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="container max-w-4xl mx-auto px-4 py-24">
        <Card>
          <CardContent className="p-8">
            <h1 className="text-2xl font-bold mb-4">Post not found</h1>
            <Link href="/blog">
              <a className="text-primary hover:underline flex items-center gap-2">
                <ArrowLeft className="w-4 h-4" /> Back to blog
              </a>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen py-24"
    >
      <div className="container max-w-4xl mx-auto px-4">
        <Link href="/blog">
          <a className="text-primary hover:underline flex items-center gap-2 mb-8">
            <ArrowLeft className="w-4 h-4" /> Back to blog
          </a>
        </Link>

        <Card className="border-primary/10">
          <CardContent className="p-8">
            <article className="prose prose-invert max-w-none">
              <h1 className="text-4xl font-bold mb-4">{post.title}</h1>
              <div className="text-muted-foreground mb-8">
                Published on {format(new Date(post.publishedAt), "MMMM d, yyyy")}
              </div>
              <div dangerouslySetInnerHTML={{ __html: post.content }} />
            </article>
          </CardContent>
        </Card>
      </div>
    </motion.div>
  );
}
