import Hero from "@/components/sections/Hero";
import AboutUs from "@/components/sections/AboutUs";
import Features from "@/components/sections/Features";
import Advantages from "@/components/sections/Advantages";
import Strategies from "@/components/sections/Strategies";
import LegitAI from "@/components/sections/LegitAI";
import BlogList from "@/components/sections/BlogList";
import Contact from "@/components/sections/Contact";

export default function Home() {
  return (
    <main className="min-h-screen">
      <Hero />
      <AboutUs />
      <Features />
      <Advantages />
      <Strategies />
      <LegitAI />
      <BlogList />
      <Contact />
    </main>
  );
}