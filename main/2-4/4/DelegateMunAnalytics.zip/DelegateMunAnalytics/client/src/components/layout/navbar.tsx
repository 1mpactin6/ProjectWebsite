import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

const navItems = [
  { path: "/", label: "Home" },
  { path: "/advantages", label: "Advantages" },
  { path: "/strategies", label: "Strategies" },
  { path: "/legit-ai", label: "Legit AI Usage" },
  { path: "/contact", label: "Contact" },
];

export function Navbar() {
  const [location] = useLocation();

  return (
    <nav className="fixed top-0 w-full z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <Link href="/">
            <a className="text-xl font-bold text-primary">DelegateMUN</a>
          </Link>
          
          <div className="hidden md:flex space-x-1">
            {navItems.map((item) => (
              <Button
                key={item.path}
                variant={location === item.path ? "default" : "ghost"}
                asChild
              >
                <Link href={item.path}>
                  <a className={cn(
                    "relative px-4",
                    location === item.path && "text-primary-foreground"
                  )}>
                    {location === item.path && (
                      <motion.div
                        layoutId="active"
                        className="absolute inset-0 bg-primary rounded-md"
                        initial={false}
                        transition={{
                          type: "spring",
                          stiffness: 500,
                          damping: 30,
                        }}
                      />
                    )}
                    <span className="relative z-10">{item.label}</span>
                  </a>
                </Link>
              </Button>
            ))}
          </div>
        </div>
      </div>
    </nav>
  );
}
