import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function Hero() {
  return (
    <section className="pt-28 pb-16 md:pt-36 md:pb-24">
      <div className="container max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid gap-12 lg:grid-cols-2 items-center">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="relative z-10 text-center lg:text-left"
          >
            <span className="text-primary font-semibold mb-4 block">Empower Your Diplomatic Voice</span>
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6 bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/70">
              Advanced Text Analysis for MUN Delegates
            </h1>
            <p className="text-lg sm:text-xl text-muted-foreground mb-8 max-w-xl mx-auto lg:mx-0">
              Empower your Model UN performance with AI-driven insights and comprehensive text analysis tools designed specifically for delegates.
            </p>
            <div className="flex gap-4 justify-center lg:justify-start">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-white px-6 sm:px-8">Try Now</Button>
              <Button size="lg" variant="outline" className="border-primary/20 hover:bg-primary/10 px-6 sm:px-8">Learn More</Button>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="relative aspect-square rounded-lg overflow-hidden max-w-xl mx-auto"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-transparent z-10 rounded-lg"></div>
            <img 
              src="https://images.unsplash.com/photo-1529070538774-1843cb3265df"
              alt="United Nations General Assembly Hall"
              className="object-cover w-full h-full rounded-lg transform hover:scale-105 transition-transform duration-500"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
}