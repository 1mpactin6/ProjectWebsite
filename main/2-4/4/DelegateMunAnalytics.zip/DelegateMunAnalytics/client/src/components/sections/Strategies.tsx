import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Brain, Search, FileText, MessageSquare } from "lucide-react";

const strategies = [
  {
    title: "Natural Language Processing",
    description: "Advanced NLP algorithms understand diplomatic context and nuances",
    icon: Brain
  },
  {
    title: "Semantic Analysis",
    description: "Deep dive into meaning and implications of diplomatic texts",
    icon: Search
  },
  {
    title: "Document Understanding",
    description: "Comprehensive analysis of resolutions and position papers",
    icon: FileText
  },
  {
    title: "Speech Analysis",
    description: "Real-time analysis of speeches and debate contributions",
    icon: MessageSquare
  }
];

export default function Strategies() {
  return (
    <section id="strategies" className="py-20">
      <div className="container max-w-6xl mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl font-bold tracking-tight mb-4 bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/70">
              Our Analysis Strategies
            </h2>
            <p className="text-lg text-muted-foreground mb-6">
              DelegateMUN employs cutting-edge methodologies to provide comprehensive text analysis tailored for Model UN delegates.
            </p>
            <div className="relative rounded-lg overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-transparent z-10"></div>
              <img 
                src="https://images.unsplash.com/photo-1517245386807-bb43f82c33c4"
                alt="Model UN Conference Session"
                className="w-full rounded-lg transform hover:scale-105 transition-transform duration-500"
              />
            </div>
          </motion.div>

          <div className="grid gap-6">
            {strategies.map((strategy, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="border-primary/10 hover:border-primary/30 transition-colors">
                  <CardContent className="p-6 flex gap-4">
                    <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <strategy.icon className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-2 text-lg">{strategy.title}</h3>
                      <p className="text-sm text-muted-foreground">
                        {strategy.description}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}