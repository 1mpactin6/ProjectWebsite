import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Brain, BookOpen, PieChart, LineChart } from "lucide-react";

export default function Strategies() {
  return (
    <div className="container mx-auto px-4 py-20">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-16"
      >
        <h1 className="text-4xl font-bold mb-4">Our Analysis Strategies</h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Learn about the advanced methodologies we use to analyze diplomatic texts
        </p>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-8">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="flex items-center gap-4">
                <Brain className="w-8 h-8 text-primary" />
                <span>Natural Language Processing</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                Our AI models use advanced NLP techniques to understand:
              </p>
              <ul className="space-y-2 text-muted-foreground">
                <li>• Document context and tone</li>
                <li>• Diplomatic language patterns</li>
                <li>• Policy implications</li>
                <li>• International relations context</li>
              </ul>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="flex items-center gap-4">
                <BookOpen className="w-8 h-8 text-primary" />
                <span>Semantic Analysis</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                Deep semantic understanding through:
              </p>
              <ul className="space-y-2 text-muted-foreground">
                <li>• Key phrase extraction</li>
                <li>• Sentiment analysis</li>
                <li>• Topic modeling</li>
                <li>• Context-aware interpretation</li>
              </ul>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="flex items-center gap-4">
                <PieChart className="w-8 h-8 text-primary" />
                <span>Statistical Analysis</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                Comprehensive statistical evaluation including:
              </p>
              <ul className="space-y-2 text-muted-foreground">
                <li>• Document complexity metrics</li>
                <li>• Readability scores</li>
                <li>• Language pattern analysis</li>
                <li>• Comparative benchmarking</li>
              </ul>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="flex items-center gap-4">
                <LineChart className="w-8 h-8 text-primary" />
                <span>Performance Metrics</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                Track and measure success through:
              </p>
              <ul className="space-y-2 text-muted-foreground">
                <li>• Quality assessment scores</li>
                <li>• Improvement tracking</li>
                <li>• Historical performance analysis</li>
                <li>• Benchmark comparisons</li>
              </ul>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
