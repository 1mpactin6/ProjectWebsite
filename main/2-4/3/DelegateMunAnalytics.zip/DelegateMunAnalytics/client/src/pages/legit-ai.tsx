import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Lock, FileCheck, Users } from "lucide-react";

export default function LegitAI() {
  return (
    <div className="container mx-auto px-4 py-20">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-16"
      >
        <h1 className="text-4xl font-bold mb-4">Legitimate AI Usage</h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Our commitment to ethical AI implementation and responsible use of technology
        </p>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-8">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="flex items-center gap-4">
                <Shield className="w-8 h-8 text-primary" />
                <span>Ethical Guidelines</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3 text-muted-foreground">
                <li>• Transparent AI decision-making processes</li>
                <li>• Regular ethical audits and compliance checks</li>
                <li>• Fair and unbiased analysis algorithms</li>
                <li>• Commitment to AI safety standards</li>
              </ul>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="flex items-center gap-4">
                <Lock className="w-8 h-8 text-primary" />
                <span>Data Privacy</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3 text-muted-foreground">
                <li>• Strict data protection protocols</li>
                <li>• End-to-end encryption</li>
                <li>• Secure data storage and handling</li>
                <li>• Regular security audits</li>
              </ul>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="flex items-center gap-4">
                <FileCheck className="w-8 h-8 text-primary" />
                <span>Compliance</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3 text-muted-foreground">
                <li>• Adherence to international AI guidelines</li>
                <li>• Regular compliance monitoring</li>
                <li>• Transparent reporting practices</li>
                <li>• Industry standard certifications</li>
              </ul>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="flex items-center gap-4">
                <Users className="w-8 h-8 text-primary" />
                <span>User Rights</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3 text-muted-foreground">
                <li>• Full control over personal data</li>
                <li>• Right to data portability</li>
                <li>• Transparent AI decision explanations</li>
                <li>• Clear terms of service</li>
              </ul>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
