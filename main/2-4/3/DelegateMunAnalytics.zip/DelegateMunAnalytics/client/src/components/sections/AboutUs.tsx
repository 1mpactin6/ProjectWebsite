import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Users, Trophy, Globe, History } from "lucide-react";

export default function AboutUs() {
  return (
    <section id="about" className="py-24">
      <div className="container max-w-7xl mx-auto px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <span className="text-primary font-semibold mb-4 block">Our Story</span>
          <h2 className="text-3xl md:text-5xl font-bold tracking-tight mb-6 bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/70">
            About DelegateMUN
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Founded by former MUN delegates, we're dedicated to empowering the next generation of diplomatic leaders
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 mb-16">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="relative rounded-lg overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-transparent z-10"></div>
            <img 
              src="https://images.unsplash.com/photo-1511578314322-379afb476865"
              alt="Team Meeting"
              className="w-full rounded-lg transform hover:scale-105 transition-transform duration-500"
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="flex flex-col justify-center"
          >
            <h3 className="text-2xl font-bold mb-4">Our Mission</h3>
            <p className="text-muted-foreground mb-6">
              At DelegateMUN, we combine cutting-edge AI technology with deep Model UN expertise to create tools that enhance delegate performance and foster meaningful diplomatic discourse.
            </p>
            <ul className="space-y-4">
              {[
                { icon: Users, text: "Team of experienced MUN delegates and AI experts" },
                { icon: Trophy, text: "Multiple award-winning delegates on our advisory board" },
                { icon: Globe, text: "Supporting delegates in over 50 countries" },
                { icon: History, text: "5+ years of MUN technology innovation" }
              ].map((item, index) => (
                <li key={index} className="flex items-center gap-3">
                  <item.icon className="w-5 h-5 text-primary" />
                  <span className="text-muted-foreground">{item.text}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center max-w-3xl mx-auto"
        >
          <Card className="border-primary/10">
            <CardContent className="p-6">
              <p className="text-lg italic text-muted-foreground">
                "We believe in the power of technology to enhance diplomatic education and make Model UN more accessible and impactful for delegates worldwide."
              </p>
              <p className="mt-4 text-primary font-semibold">- The DelegateMUN Team</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}
