import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Menu } from "lucide-react";
import { useState } from "react";

const navigationItems = [
  { href: "#about", label: "About Us" },
  { href: "#features", label: "Features" },
  { href: "#advantages", label: "Advantages" },
  { href: "#strategies", label: "Strategies" },
  { href: "#legitai", label: "Legit AI" },
  { href: "#contact", label: "Contact" }
];

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <nav className="fixed top-0 w-full bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 z-50 border-b border-border">
      <div className="container max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex h-16 items-center justify-between">
          <Link href="/">
            <a className="flex items-center space-x-2">
              <span className="font-bold text-xl text-primary">DelegateMUN</span>
            </a>
          </Link>

          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="lg:hidden"
          >
            <Menu className="h-6 w-6" />
          </button>

          <div className="hidden lg:flex lg:gap-6">
            {navigationItems.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="text-sm font-medium transition-colors hover:text-primary"
              >
                {item.label}
              </a>
            ))}
          </div>

          <div className="hidden lg:flex lg:items-center lg:space-x-4">
            <Button variant="outline" className="border-primary/20 hover:bg-primary/10 text-primary">Login</Button>
            <Button className="bg-primary hover:bg-primary/90 text-white">Get Started</Button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="lg:hidden py-4">
            <div className="flex flex-col space-y-4">
              {navigationItems.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  className="text-sm font-medium transition-colors hover:text-primary px-2"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.label}
                </a>
              ))}
              <div className="flex flex-col space-y-2 pt-2">
                <Button variant="outline" className="border-primary/20 hover:bg-primary/10 text-primary w-full">Login</Button>
                <Button className="bg-primary hover:bg-primary/90 text-white w-full">Get Started</Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}