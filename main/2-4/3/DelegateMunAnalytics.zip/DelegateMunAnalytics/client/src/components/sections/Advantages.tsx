import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { motion } from "framer-motion";
import { Zap, Target, Clock, Shield } from "lucide-react";

const advantages = [
  {
    title: "Enhanced Accuracy",
    description: "AI-powered analysis ensures precise interpretation of diplomatic texts and resolutions.",
    icon: Target
  },
  {
    title: "Real-time Processing",
    description: "Process and analyze documents instantly during committee sessions.",
    icon: Clock
  },
  {
    title: "Advanced Security",
    description: "Your documents are protected with enterprise-grade encryption.",
    icon: Shield
  },
  {
    title: "Quick Integration",
    description: "Seamlessly integrate with your existing MUN workflow.",
    icon: Zap
  }
];

export default function Advantages() {
  return (
    <section id="advantages" className="py-24 bg-muted/50">
      <div className="container max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-bold tracking-tight mb-6 bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/70">
            Why Choose DelegateMUN
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Our platform offers unique advantages that enhance your Model UN experience
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
          {advantages.map((advantage, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="h-full border-primary/10 hover:border-primary/30 transition-colors">
                <CardHeader>
                  <div className="mb-4 w-14 h-14 rounded-lg bg-primary/10 flex items-center justify-center mx-auto">
                    <advantage.icon className="w-7 h-7 text-primary" />
                  </div>
                  <CardTitle className="text-xl mb-3 text-center">{advantage.title}</CardTitle>
                  <CardDescription className="text-muted-foreground text-center">{advantage.description}</CardDescription>
                </CardHeader>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}