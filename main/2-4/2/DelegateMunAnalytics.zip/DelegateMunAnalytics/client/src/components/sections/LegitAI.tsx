import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Shield, Lock, UserCheck, Scale } from "lucide-react";

export default function LegitAI() {
  return (
    <section id="legitai" className="py-20 bg-muted/50">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl mx-auto text-center mb-12"
        >
          <h2 className="text-3xl font-bold tracking-tight mb-4">
            Legitimate AI Usage
          </h2>
          <p className="text-lg text-muted-foreground">
            We are committed to ethical AI practices and ensuring fair use of technology in Model UN competitions.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6 mb-12">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <Card className="h-full">
              <CardContent className="p-6">
                <div className="flex items-center gap-4 mb-4">
                  <Shield className="w-8 h-8 text-primary" />
                  <h3 className="text-xl font-semibold">Compliance</h3>
                </div>
                <p className="text-muted-foreground">
                  Our AI tools strictly adhere to Model UN competition guidelines and ethical standards for AI usage in academic contexts.
                </p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <Card className="h-full">
              <CardContent className="p-6">
                <div className="flex items-center gap-4 mb-4">
                  <Lock className="w-8 h-8 text-primary" />
                  <h3 className="text-xl font-semibold">Data Privacy</h3>
                </div>
                <p className="text-muted-foreground">
                  Your documents and analysis data are protected with enterprise-grade security measures and never shared with third parties.
                </p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Card className="h-full">
              <CardContent className="p-6">
                <div className="flex items-center gap-4 mb-4">
                  <UserCheck className="w-8 h-8 text-primary" />
                  <h3 className="text-xl font-semibold">Fair Use</h3>
                </div>
                <p className="text-muted-foreground">
                  We ensure that AI assistance enhances your research and analysis without compromising the integrity of your work.
                </p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <Card className="h-full">
              <CardContent className="p-6">
                <div className="flex items-center gap-4 mb-4">
                  <Scale className="w-8 h-8 text-primary" />
                  <h3 className="text-xl font-semibold">Transparency</h3>
                </div>
                <p className="text-muted-foreground">
                  Full disclosure of AI usage in analysis results and clear documentation of how our tools assist delegates.
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
