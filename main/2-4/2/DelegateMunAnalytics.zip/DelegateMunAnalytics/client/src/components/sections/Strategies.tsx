import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Brain, Search, FileText, MessageSquare } from "lucide-react";

const strategies = [
  {
    title: "Natural Language Processing",
    description: "Advanced NLP algorithms understand diplomatic context and nuances",
    icon: Brain
  },
  {
    title: "Semantic Analysis",
    description: "Deep dive into meaning and implications of diplomatic texts",
    icon: Search
  },
  {
    title: "Document Understanding",
    description: "Comprehensive analysis of resolutions and position papers",
    icon: FileText
  },
  {
    title: "Speech Analysis",
    description: "Real-time analysis of speeches and debate contributions",
    icon: MessageSquare
  }
];

export default function Strategies() {
  return (
    <section id="strategies" className="py-20">
      <div className="container">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl font-bold tracking-tight mb-4">
              Our Analysis Strategies
            </h2>
            <p className="text-lg text-muted-foreground mb-6">
              DelegateMUN employs cutting-edge methodologies to provide comprehensive text analysis tailored for Model UN delegates.
            </p>
            <img 
              src="https://images.unsplash.com/photo-1627389955611-70c92a5d2e2b"
              alt="Abstract technology visualization"
              className="rounded-lg"
            />
          </motion.div>
          
          <div className="grid gap-6">
            {strategies.map((strategy, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card>
                  <CardContent className="p-6 flex gap-4">
                    <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <strategy.icon className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-2">{strategy.title}</h3>
                      <p className="text-sm text-muted-foreground">
                        {strategy.description}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
