import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Sparkles, Bot, FileSearch, PenTool, Gauge, GitCompare } from "lucide-react";

const features = [
  {
    icon: Sparkles,
    title: "Smart Resolution Analysis",
    description: "Advanced AI algorithms analyze resolution drafts for clarity, coherence, and diplomatic language."
  },
  {
    icon: Bot,
    title: "AI Research Assistant",
    description: "Get instant access to relevant country policies, historical data, and UN precedents."
  },
  {
    icon: FileSearch,
    title: "Position Paper Review",
    description: "Automated feedback on position papers with suggestions for improvement and formatting."
  },
  {
    icon: PenTool,
    title: "Speech Enhancement",
    description: "Real-time analysis of speech drafts for impactful diplomatic rhetoric."
  },
  {
    icon: Gauge,
    title: "Performance Analytics",
    description: "Track your progress and get personalized recommendations for improvement."
  },
  {
    icon: GitCompare,
    title: "Collaborative Tools",
    description: "Work seamlessly with your delegation team on shared documents and analysis."
  }
];

export default function Features() {
  return (
    <section id="features" className="py-24 bg-muted/50">
      <div className="container max-w-7xl mx-auto px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <span className="text-primary font-semibold mb-4 block">What We Offer</span>
          <h2 className="text-3xl md:text-5xl font-bold tracking-tight mb-6 bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/70">
            Comprehensive Features
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Everything you need to excel in your Model UN journey
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="h-full border-primary/10 hover:border-primary/30 transition-colors">
                <CardContent className="p-6">
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-6">
                    <feature.icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
