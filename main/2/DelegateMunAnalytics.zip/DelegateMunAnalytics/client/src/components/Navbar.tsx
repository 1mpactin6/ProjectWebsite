import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Navbar() {
  return (
    <nav className="fixed top-0 w-full bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 z-50 border-b border-border">
      <div className="container flex h-16 items-center">
        <Link href="/">
          <a className="mr-8 flex items-center space-x-2">
            <span className="font-bold text-xl">DelegateMUN</span>
          </a>
        </Link>
        <div className="flex gap-6">
          <a href="#advantages" className="text-sm font-medium transition-colors hover:text-primary">
            Advantages
          </a>
          <a href="#strategies" className="text-sm font-medium transition-colors hover:text-primary">
            Strategies
          </a>
          <a href="#legitai" className="text-sm font-medium transition-colors hover:text-primary">
            Legit AI
          </a>
          <a href="#contact" className="text-sm font-medium transition-colors hover:text-primary">
            Contact
          </a>
        </div>
        <div className="ml-auto flex items-center space-x-4">
          <Button variant="outline">Login</Button>
          <Button>Get Started</Button>
        </div>
      </div>
    </nav>
  );
}
