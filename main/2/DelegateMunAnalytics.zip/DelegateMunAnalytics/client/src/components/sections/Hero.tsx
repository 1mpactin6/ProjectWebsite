import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function Hero() {
  return (
    <section className="pt-24 pb-12 md:pt-32 md:pb-20">
      <div className="container">
        <div className="grid gap-8 md:grid-cols-2 items-center">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-4">
              Advanced Text Analysis for MUN Delegates
            </h1>
            <p className="text-lg text-muted-foreground mb-8">
              Empower your Model UN performance with AI-driven insights and comprehensive text analysis tools designed specifically for delegates.
            </p>
            <div className="flex gap-4">
              <Button size="lg">Try Now</Button>
              <Button size="lg" variant="outline">Learn More</Button>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="relative aspect-square rounded-lg overflow-hidden"
          >
            <img 
              src="https://images.unsplash.com/photo-1721066115321-eb0eec055296"
              alt="AI Technology Visualization"
              className="object-cover w-full h-full rounded-lg"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
