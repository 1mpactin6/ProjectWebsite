import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { motion } from "framer-motion";
import { Zap, Target, Clock, Shield } from "lucide-react";

const advantages = [
  {
    title: "Enhanced Accuracy",
    description: "AI-powered analysis ensures precise interpretation of diplomatic texts and resolutions.",
    icon: Target
  },
  {
    title: "Real-time Processing",
    description: "Process and analyze documents instantly during committee sessions.",
    icon: Clock
  },
  {
    title: "Advanced Security",
    description: "Your documents are protected with enterprise-grade encryption.",
    icon: Shield
  },
  {
    title: "Quick Integration",
    description: "Seamlessly integrate with your existing MUN workflow.",
    icon: Zap
  }
];

export default function Advantages() {
  return (
    <section id="advantages" className="py-20 bg-muted/50">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold tracking-tight mb-4">Why Choose DelegateMUN</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Our platform offers unique advantages that enhance your Model UN experience
          </p>
        </motion.div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {advantages.map((advantage, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="h-full">
                <CardHeader>
                  <div className="mb-4 w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                    <advantage.icon className="w-6 h-6 text-primary" />
                  </div>
                  <CardTitle>{advantage.title}</CardTitle>
                  <CardDescription>{advantage.description}</CardDescription>
                </CardHeader>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
