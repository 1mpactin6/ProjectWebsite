import Hero from "@/components/sections/Hero";
import Advantages from "@/components/sections/Advantages";
import Strategies from "@/components/sections/Strategies";
import LegitAI from "@/components/sections/LegitAI";
import Contact from "@/components/sections/Contact";

export default function Home() {
  return (
    <main className="min-h-screen">
      <Hero />
      <Advantages />
      <Strategies />
      <LegitAI />
      <Contact />
    </main>
  );
}
