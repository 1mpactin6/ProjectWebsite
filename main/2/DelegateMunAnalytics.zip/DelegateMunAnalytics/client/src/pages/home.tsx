import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ChevronRight, Bot, LineChart, ShieldCheck } from "lucide-react";

export default function Home() {
  return (
    <div className="container mx-auto px-4">
      <section className="py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center"
        >
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/60">
            DelegateMUN Text Analysis
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
            Advanced AI-powered text analysis tailored for Model United Nations delegates
          </p>
          <div className="flex justify-center gap-4">
            <Button size="lg" asChild>
              <Link href="/advantages">
                Explore Features <ChevronRight className="ml-2" />
              </Link>
            </Button>
          </div>
        </motion.div>
      </section>

      <section className="py-20">
        <div className="grid md:grid-cols-3 gap-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="p-6 rounded-lg border bg-card"
          >
            <Bot className="w-12 h-12 text-primary mb-4" />
            <h3 className="text-xl font-semibold mb-2">AI-Powered Analysis</h3>
            <p className="text-muted-foreground">
              State-of-the-art natural language processing for comprehensive text analysis
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="p-6 rounded-lg border bg-card"
          >
            <LineChart className="w-12 h-12 text-primary mb-4" />
            <h3 className="text-xl font-semibold mb-2">Real-time Insights</h3>
            <p className="text-muted-foreground">
              Instant feedback and analysis to improve your diplomatic documents
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="p-6 rounded-lg border bg-card"
          >
            <ShieldCheck className="w-12 h-12 text-primary mb-4" />
            <h3 className="text-xl font-semibold mb-2">Ethical AI Usage</h3>
            <p className="text-muted-foreground">
              Committed to responsible AI implementation and data privacy
            </p>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
